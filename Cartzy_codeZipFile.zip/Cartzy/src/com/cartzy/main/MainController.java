package com.cartzy.main;

import com.cartzy.app.UI;

public class MainController {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UI ui=new UI();
		ui.UILauncher();

	}

}
